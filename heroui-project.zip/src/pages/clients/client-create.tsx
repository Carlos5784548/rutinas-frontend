import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Card, 
  CardBody, 
  Input, 
  Button, 
  Divider 
} from '@heroui/react';
import { Icon } from '@iconify/react';
import { useForm, Controller } from 'react-hook-form';
import { PageHeader } from '../../components/ui/page-header';
import { clientApi } from '../../services/api';
import { ClientFormData } from '../../types';
import { addToast } from '@heroui/react';

export const ClientCreate: React.FC = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  
  const { 
    control, 
    handleSubmit, 
    formState: { errors } 
  } = useForm<ClientFormData>({
    defaultValues: {
      nombre: '',
      email: '',
      telefono: '',
      edad: 18,
      usuario: {
        nombre: '',
        email: '',
        password: '',
        rol: 'CLIENTE'
      }
    }
  });
  
  const onSubmit = async (data: ClientFormData) => {
    try {
      setIsSubmitting(true);
      await clientApi.create({
        nombre: data.nombre,
        email: data.email,
        telefono: data.telefono,
        edad: data.edad,
        usuario: {
          nombre: data.usuario.nombre,
          email: data.usuario.email,
          password: data.usuario.password,
          rol: 'CLIENTE'
        }
      });
      
      addToast({
        title: 'Cliente creado',
        description: 'El cliente ha sido creado correctamente',
        severity: 'success'
      });
      navigate('/clientes');
    } catch (error) {
      console.error('Error creating client:', error);
      addToast({
        title: 'Error',
        description: 'No se pudo crear el cliente',
        severity: 'danger'
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div>
      <PageHeader 
        title="Crear Cliente" 
        description="Añade un nuevo cliente al sistema" 
        backLink="/clientes"
      />
      
      <Card className="max-w-xl mx-auto">
        <CardBody className="p-6">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <h3 className="text-lg font-medium">Información del Cliente</h3>
            
            <Controller
              name="nombre"
              control={control}
              rules={{ 
                required: 'El nombre es obligatorio',
                minLength: {
                  value: 3,
                  message: 'El nombre debe tener al menos 3 caracteres'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  label="Nombre"
                  placeholder="Ingrese el nombre completo"
                  isRequired
                  isInvalid={!!errors.nombre}
                  errorMessage={errors.nombre?.message}
                />
              )}
            />
            
            <Controller
              name="email"
              control={control}
              rules={{ 
                required: 'El email es obligatorio',
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Ingrese un email válido'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  type="email"
                  label="Email"
                  placeholder="ejemplo@correo.com"
                  isRequired
                  isInvalid={!!errors.email}
                  errorMessage={errors.email?.message}
                />
              )}
            />
            
            <Controller
              name="telefono"
              control={control}
              rules={{ 
                required: 'El teléfono es obligatorio',
                pattern: {
                  value: /^[0-9]{9,15}$/,
                  message: 'Ingrese un número de teléfono válido'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  label="Teléfono"
                  placeholder="Ingrese el número de teléfono"
                  isRequired
                  isInvalid={!!errors.telefono}
                  errorMessage={errors.telefono?.message}
                />
              )}
            />
            
            <Controller
              name="edad"
              control={control}
              rules={{ 
                required: 'La edad es obligatoria',
                min: {
                  value: 1,
                  message: 'La edad debe ser mayor a 0'
                },
                max: {
                  value: 120,
                  message: 'La edad debe ser menor a 120'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  type="number"
                  label="Edad"
                  placeholder="Ingrese la edad"
                  isRequired
                  isInvalid={!!errors.edad}
                  errorMessage={errors.edad?.message}
                  value={field.value.toString()}
                  onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                />
              )}
            />
            
            <Divider className="my-4" />
            
            <h3 className="text-lg font-medium">Información de Usuario</h3>
            <p className="text-sm text-default-500 mb-4">Se creará un usuario con rol de Cliente asociado a este cliente.</p>
            
            <Controller
              name="usuario.nombre"
              control={control}
              rules={{ 
                required: 'El nombre de usuario es obligatorio',
                minLength: {
                  value: 3,
                  message: 'El nombre debe tener al menos 3 caracteres'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  label="Nombre de Usuario"
                  placeholder="Ingrese el nombre de usuario"
                  isRequired
                  isInvalid={!!errors.usuario?.nombre}
                  errorMessage={errors.usuario?.nombre?.message}
                />
              )}
            />
            
            <Controller
              name="usuario.email"
              control={control}
              rules={{ 
                required: 'El email de usuario es obligatorio',
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Ingrese un email válido'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  type="email"
                  label="Email de Usuario"
                  placeholder="ejemplo@correo.com"
                  isRequired
                  isInvalid={!!errors.usuario?.email}
                  errorMessage={errors.usuario?.email?.message}
                />
              )}
            />
            
            <Controller
              name="usuario.password"
              control={control}
              rules={{ 
                required: 'La contraseña es obligatoria',
                minLength: {
                  value: 6,
                  message: 'La contraseña debe tener al menos 6 caracteres'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  type="password"
                  label="Contraseña"
                  placeholder="Ingrese una contraseña"
                  isRequired
                  isInvalid={!!errors.usuario?.password}
                  errorMessage={errors.usuario?.password?.message}
                />
              )}
            />
            
            <div className="flex justify-end gap-3 pt-4">
              <Button
                variant="flat"
                onPress={() => navigate('/clientes')}
                isDisabled={isSubmitting}
              >
                Cancelar
              </Button>
              <Button
                color="primary"
                type="submit"
                isLoading={isSubmitting}
                startContent={!isSubmitting && <Icon icon="lucide:save" className="h-4 w-4" />}
              >
                Guardar
              </Button>
            </div>
          </form>
        </CardBody>
      </Card>
    </div>
  );
};