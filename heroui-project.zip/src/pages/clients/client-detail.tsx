import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Button, 
  Spinner, 
  Table, 
  TableHeader, 
  TableColumn, 
  TableBody, 
  TableRow, 
  TableCell,
  Chip,
  Divider,
  Tabs,
  Tab
} from '@heroui/react';
import { Icon } from '@iconify/react';
import { PageHeader } from '../../components/ui/page-header';
import { EmptyState } from '../../components/ui/empty-state';
import { clientApi } from '../../services/api';
import { Client, Routine } from '../../types';
import { addToast } from '@heroui/react';

export const ClientDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [client, setClient] = React.useState<Client | null>(null);
  const [routines, setRoutines] = React.useState<Routine[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [routinesLoading, setRoutinesLoading] = React.useState(true);
  
  React.useEffect(() => {
    if (id) {
      fetchClient(parseInt(id));
      fetchClientRoutines(parseInt(id));
    }
  }, [id]);
  
  const fetchClient = async (clientId: number) => {
    try {
      setLoading(true);
      const data = await clientApi.getById(clientId);
      setClient(data);
    } catch (error) {
      console.error('Error fetching client:', error);
      addToast({
        title: 'Error',
        description: 'No se pudo cargar la información del cliente',
        severity: 'danger'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const fetchClientRoutines = async (clientId: number) => {
    try {
      setRoutinesLoading(true);
      const data = await clientApi.getRoutines(clientId);
      setRoutines(data);
    } catch (error) {
      console.error('Error fetching client routines:', error);
      addToast({
        title: 'Error',
        description: 'No se pudieron cargar las rutinas del cliente',
        severity: 'danger'
      });
    } finally {
      setRoutinesLoading(false);
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };
  
  const getEnfoqueColor = (enfoque: string): "default" | "primary" | "secondary" | "success" | "warning" | "danger" => {
    switch (enfoque) {
      case 'Tonificar':
        return 'success';
      case 'Volumen':
        return 'primary';
      case 'Resistencia':
        return 'warning';
      default:
        return 'default';
    }
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" color="primary" />
      </div>
    );
  }
  
  if (!client) {
    return (
      <EmptyState
        title="Cliente no encontrado"
        description="El cliente que estás buscando no existe o ha sido eliminado."
        icon="lucide:user-x"
        actionLabel="Volver a Clientes"
        actionPath="/clientes"
      />
    );
  }
  
  return (
    <div>
      <PageHeader 
        title={`Cliente: ${client.nombre}`}
        backLink="/clientes"
        actionLabel="Editar Cliente"
        actionIcon="lucide:pencil"
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card className="shadow-sm">
            <CardHeader className="flex justify-between items-center">
              <h2 className="text-lg font-medium">Información Personal</h2>
            </CardHeader>
            <CardBody className="space-y-4">
              <div>
                <p className="text-sm text-default-500">Nombre</p>
                <p className="font-medium">{client.nombre}</p>
              </div>
              
              <div>
                <p className="text-sm text-default-500">Email</p>
                <p className="font-medium">{client.email}</p>
              </div>
              
              <div>
                <p className="text-sm text-default-500">Teléfono</p>
                <p className="font-medium">{client.telefono}</p>
              </div>
              
              <div>
                <p className="text-sm text-default-500">Edad</p>
                <p className="font-medium">{client.edad} años</p>
              </div>
              
              {client.usuario && (
                <>
                  <Divider />
                  <div>
                    <p className="text-sm text-default-500">Usuario Asociado</p>
                    <p className="font-medium">{client.usuario.nombre}</p>
                    <p className="text-sm text-default-500 mt-1">Email de Usuario</p>
                    <p className="font-medium">{client.usuario.email}</p>
                  </div>
                </>
              )}
            </CardBody>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <Card className="shadow-sm">
            <CardHeader className="flex justify-between items-center">
              <h2 className="text-lg font-medium">Rutinas</h2>
              <Button
                as={Link}
                to={`/rutinas/crear?clienteId=${client.id}`}
                color="primary"
                size="sm"
                startContent={<Icon icon="lucide:plus" className="h-4 w-4" />}
              >
                Nueva Rutina
              </Button>
            </CardHeader>
            <CardBody>
              {routinesLoading ? (
                <div className="flex justify-center items-center h-40">
                  <Spinner size="md" color="primary" />
                </div>
              ) : routines.length === 0 ? (
                <EmptyState
                  title="Sin rutinas"
                  description="Este cliente aún no tiene rutinas asignadas."
                  icon="lucide:clipboard"
                  actionLabel="Crear Rutina"
                  actionPath={`/rutinas/crear?clienteId=${client.id}`}
                />
              ) : (
                <Table removeWrapper aria-label="Rutinas del cliente">
                  <TableHeader>
                    <TableColumn>NOMBRE</TableColumn>
                    <TableColumn>ENFOQUE</TableColumn>
                    <TableColumn>FECHA INICIO</TableColumn>
                    <TableColumn>FECHA FIN</TableColumn>
                    <TableColumn>ACCIONES</TableColumn>
                  </TableHeader>
                  <TableBody>
                    {routines.map((routine) => (
                      <TableRow key={routine.id}>
                        <TableCell>{routine.nombre}</TableCell>
                        <TableCell>
                          <Chip color={getEnfoqueColor(routine.enfoque)} size="sm">
                            {routine.enfoque}
                          </Chip>
                        </TableCell>
                        <TableCell>{formatDate(routine.fechaInicio)}</TableCell>
                        <TableCell>{formatDate(routine.fechaFin)}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              as={Link}
                              to={`/rutinas/${routine.id}`}
                              size="sm"
                              variant="flat"
                              color="primary"
                              isIconOnly
                            >
                              <Icon icon="lucide:eye" className="h-4 w-4" />
                            </Button>
                            <Button
                              as={Link}
                              to={`/rutinas/${routine.id}`}
                              size="sm"
                              variant="flat"
                              isIconOnly
                            >
                              <Icon icon="lucide:edit" className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
};