import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Card, 
  CardBody, 
  CardHeader, 
  Button, 
  Spinner, 
  Table, 
  TableHeader, 
  TableColumn, 
  TableBody, 
  TableRow, 
  TableCell,
  Chip,
  Divider,
  Modal,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  useDisclosure,
  Input,
  Select,
  SelectItem
} from '@heroui/react';
import { Icon } from '@iconify/react';
import { useForm, Controller } from 'react-hook-form';
import { PageHeader } from '../../components/ui/page-header';
import { EmptyState } from '../../components/ui/empty-state';
import { ConfirmationModal } from '../../components/ui/confirmation-modal';
import { routineApi, exerciseApi } from '../../services/api';
import { Routine, Exercise, RoutineExercise, RoutineExerciseFormData } from '../../types';
import { addToast } from '@heroui/react';

export const RoutineDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { isOpen, onOpen, onOpenChange, onClose } = useDisclosure();
  const [routine, setRoutine] = React.useState<Routine | null>(null);
  const [routineExercises, setRoutineExercises] = React.useState<RoutineExercise[]>([]);
  const [exercises, setExercises] = React.useState<Exercise[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [exercisesLoading, setExercisesLoading] = React.useState(true);
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = React.useState(false);
  const [exerciseToDelete, setExerciseToDelete] = React.useState<RoutineExercise | null>(null);
  const [isDeleting, setIsDeleting] = React.useState(false);
  
  const { 
    control, 
    handleSubmit, 
    formState: { errors },
    reset
  } = useForm<RoutineExerciseFormData>({
    defaultValues: {
      ejercicioId: 0,
      series: 3,
      repeticiones: 12,
      descansoSegundos: 60
    }
  });
  
  React.useEffect(() => {
    if (id) {
      fetchRoutine(parseInt(id));
      fetchRoutineExercises(parseInt(id));
      fetchExercises();
    }
  }, [id]);
  
  const fetchRoutine = async (routineId: number) => {
    try {
      setLoading(true);
      const data = await routineApi.getById(routineId);
      setRoutine(data);
    } catch (error) {
      console.error('Error fetching routine:', error);
      addToast({
        title: 'Error',
        description: 'No se pudo cargar la información de la rutina',
        severity: 'danger'
      });
    } finally {
      setLoading(false);
    }
  };
  
  const fetchRoutineExercises = async (routineId: number) => {
    try {
      const data = await routineApi.getExercises(routineId);
      setRoutineExercises(data);
    } catch (error) {
      console.error('Error fetching routine exercises:', error);
      addToast({
        title: 'Error',
        description: 'No se pudieron cargar los ejercicios de la rutina',
        severity: 'danger'
      });
    }
  };
  
  const fetchExercises = async () => {
    try {
      setExercisesLoading(true);
      const data = await exerciseApi.getAll();
      setExercises(data);
    } catch (error) {
      console.error('Error fetching exercises:', error);
    } finally {
      setExercisesLoading(false);
    }
  };
  
  const onSubmit = async (data: RoutineExerciseFormData) => {
    if (!id) return;
    
    try {
      setIsSubmitting(true);
      await routineApi.addExercise(parseInt(id), {
        ejercicioId: data.ejercicioId,
        series: data.series,
        repeticiones: data.repeticiones,
        descansoSegundos: data.descansoSegundos
      });
      
      fetchRoutineExercises(parseInt(id));
      reset();
      onClose();
      
      addToast({
        title: 'Ejercicio añadido',
        description: 'El ejercicio ha sido añadido a la rutina correctamente',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error adding exercise to routine:', error);
      addToast({
        title: 'Error',
        description: 'No se pudo añadir el ejercicio a la rutina',
        severity: 'danger'
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleDeleteClick = (exercise: RoutineExercise) => {
    setExerciseToDelete(exercise);
    setDeleteModalOpen(true);
  };
  
  const handleDeleteConfirm = async () => {
    if (!id || !exerciseToDelete?.id) return;
    
    try {
      setIsDeleting(true);
      await routineApi.removeExercise(parseInt(id), exerciseToDelete.id);
      setRoutineExercises(routineExercises.filter(ex => ex.id !== exerciseToDelete.id));
      addToast({
        title: 'Ejercicio eliminado',
        description: 'El ejercicio ha sido eliminado de la rutina correctamente',
        severity: 'success'
      });
    } catch (error) {
      console.error('Error removing exercise from routine:', error);
      addToast({
        title: 'Error',
        description: 'No se pudo eliminar el ejercicio de la rutina',
        severity: 'danger'
      });
    } finally {
      setIsDeleting(false);
      setDeleteModalOpen(false);
      setExerciseToDelete(null);
    }
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };
  
  const getEnfoqueColor = (enfoque: string): "default" | "primary" | "secondary" | "success" | "warning" | "danger" => {
    switch (enfoque) {
      case 'Tonificar':
        return 'success';
      case 'Volumen':
        return 'primary';
      case 'Resistencia':
        return 'warning';
      default:
        return 'default';
    }
  };
  
  const getExerciseName = (exerciseId: number) => {
    const exercise = exercises.find(ex => ex.id === exerciseId);
    return exercise ? exercise.nombre : 'Ejercicio no encontrado';
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Spinner size="lg" color="primary" />
      </div>
    );
  }
  
  if (!routine) {
    return (
      <EmptyState
        title="Rutina no encontrada"
        description="La rutina que estás buscando no existe o ha sido eliminada."
        icon="lucide:clipboard-x"
        actionLabel="Volver a Rutinas"
        actionPath="/rutinas"
      />
    );
  }
  
  return (
    <div>
      <PageHeader 
        title={`Rutina: ${routine.nombre}`}
        backLink="/rutinas"
        actionLabel="Editar Rutina"
        actionIcon="lucide:pencil"
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <Card className="shadow-sm">
            <CardHeader className="flex justify-between items-center">
              <h2 className="text-lg font-medium">Información de la Rutina</h2>
            </CardHeader>
            <CardBody className="space-y-4">
              <div>
                <p className="text-sm text-default-500">Nombre</p>
                <p className="font-medium">{routine.nombre}</p>
              </div>
              
              <div>
                <p className="text-sm text-default-500">Enfoque</p>
                <Chip color={getEnfoqueColor(routine.enfoque)} size="sm">
                  {routine.enfoque}
                </Chip>
              </div>
              
              <div>
                <p className="text-sm text-default-500">Fecha de Inicio</p>
                <p className="font-medium">{formatDate(routine.fechaInicio)}</p>
              </div>
              
              <div>
                <p className="text-sm text-default-500">Fecha de Fin</p>
                <p className="font-medium">{formatDate(routine.fechaFin)}</p>
              </div>
              
              {routine.cliente && (
                <>
                  <Divider />
                  <div>
                    <p className="text-sm text-default-500">Cliente</p>
                    <p className="font-medium">{routine.cliente.nombre}</p>
                    <Button
                      as={Link}
                      to={`/clientes/${routine.clienteId}`}
                      variant="flat"
                      color="primary"
                      size="sm"
                      className="mt-2"
                      startContent={<Icon icon="lucide:user" className="h-4 w-4" />}
                    >
                      Ver Cliente
                    </Button>
                  </div>
                </>
              )}
            </CardBody>
          </Card>
        </div>
        
        <div className="lg:col-span-2">
          <Card className="shadow-sm">
            <CardHeader className="flex justify-between items-center">
              <h2 className="text-lg font-medium">Ejercicios</h2>
              <Button
                color="primary"
                size="sm"
                startContent={<Icon icon="lucide:plus" className="h-4 w-4" />}
                onPress={onOpen}
              >
                Añadir Ejercicio
              </Button>
            </CardHeader>
            <CardBody>
              {routineExercises.length === 0 ? (
                <EmptyState
                  title="Sin ejercicios"
                  description="Esta rutina aún no tiene ejercicios asignados."
                  icon="lucide:dumbbell"
                  actionLabel="Añadir Ejercicio"
                  onActionClick={onOpen}
                />
              ) : (
                <Table removeWrapper aria-label="Ejercicios de la rutina">
                  <TableHeader>
                    <TableColumn>EJERCICIO</TableColumn>
                    <TableColumn>SERIES</TableColumn>
                    <TableColumn>REPETICIONES</TableColumn>
                    <TableColumn>DESCANSO (SEG)</TableColumn>
                    <TableColumn>ACCIONES</TableColumn>
                  </TableHeader>
                  <TableBody>
                    {routineExercises.map((exercise) => (
                      <TableRow key={exercise.id}>
                        <TableCell>{getExerciseName(exercise.ejercicioId)}</TableCell>
                        <TableCell>{exercise.series}</TableCell>
                        <TableCell>{exercise.repeticiones}</TableCell>
                        <TableCell>{exercise.descansoSegundos}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="flat"
                              color="danger"
                              isIconOnly
                              onPress={() => handleDeleteClick(exercise)}
                            >
                              <Icon icon="lucide:trash" className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardBody>
          </Card>
        </div>
      </div>
      
      <Modal isOpen={isOpen} onOpenChange={onOpenChange}>
        <ModalContent>
          {(onClose) => (
            <form onSubmit={handleSubmit(onSubmit)}>
              <ModalHeader className="flex flex-col gap-1">Añadir Ejercicio a la Rutina</ModalHeader>
              <ModalBody>
                {exercisesLoading ? (
                  <div className="flex justify-center items-center h-40">
                    <Spinner size="lg" color="primary" />
                  </div>
                ) : (
                  <div className="space-y-4">
                    <Controller
                      name="ejercicioId"
                      control={control}
                      rules={{ 
                        required: 'El ejercicio es obligatorio',
                        validate: value => value > 0 || 'Debe seleccionar un ejercicio'
                      }}
                      render={({ field }) => (
                        <Select
                          label="Ejercicio"
                          placeholder="Seleccione un ejercicio"
                          selectedKeys={field.value ? [field.value.toString()] : []}
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                          isRequired
                          isInvalid={!!errors.ejercicioId}
                          errorMessage={errors.ejercicioId?.message}
                        >
                          {exercises.map((exercise) => (
                            <SelectItem key={exercise.id?.toString()} value={exercise.id?.toString() || ''}>
                              {exercise.nombre} - {exercise.grupoMuscular}
                            </SelectItem>
                          ))}
                        </Select>
                      )}
                    />
                    
                    <Controller
                      name="series"
                      control={control}
                      rules={{ 
                        required: 'El número de series es obligatorio',
                        min: {
                          value: 1,
                          message: 'El número de series debe ser al menos 1'
                        },
                        max: {
                          value: 20,
                          message: 'El número de series no debe exceder 20'
                        }
                      }}
                      render={({ field }) => (
                        <Input
                          type="number"
                          label="Series"
                          placeholder="Ingrese el número de series"
                          isRequired
                          isInvalid={!!errors.series}
                          errorMessage={errors.series?.message}
                          value={field.value.toString()}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      )}
                    />
                    
                    <Controller
                      name="repeticiones"
                      control={control}
                      rules={{ 
                        required: 'El número de repeticiones es obligatorio',
                        min: {
                          value: 1,
                          message: 'El número de repeticiones debe ser al menos 1'
                        },
                        max: {
                          value: 100,
                          message: 'El número de repeticiones no debe exceder 100'
                        }
                      }}
                      render={({ field }) => (
                        <Input
                          type="number"
                          label="Repeticiones"
                          placeholder="Ingrese el número de repeticiones"
                          isRequired
                          isInvalid={!!errors.repeticiones}
                          errorMessage={errors.repeticiones?.message}
                          value={field.value.toString()}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      )}
                    />
                    
                    <Controller
                      name="descansoSegundos"
                      control={control}
                      rules={{ 
                        required: 'El tiempo de descanso es obligatorio',
                        min: {
                          value: 0,
                          message: 'El tiempo de descanso no puede ser negativo'
                        },
                        max: {
                          value: 300,
                          message: 'El tiempo de descanso no debe exceder 300 segundos'
                        }
                      }}
                      render={({ field }) => (
                        <Input
                          type="number"
                          label="Descanso (segundos)"
                          placeholder="Ingrese el tiempo de descanso en segundos"
                          isRequired
                          isInvalid={!!errors.descansoSegundos}
                          errorMessage={errors.descansoSegundos?.message}
                          value={field.value.toString()}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      )}
                    />
                  </div>
                )}
              </ModalBody>
              <ModalFooter>
                <Button variant="flat" onPress={onClose} isDisabled={isSubmitting}>
                  Cancelar
                </Button>
                <Button 
                  color="primary" 
                  type="submit"
                  isLoading={isSubmitting}
                >
                  Añadir
                </Button>
              </ModalFooter>
            </form>
          )}
        </ModalContent>
      </Modal>
      
      <ConfirmationModal
        isOpen={deleteModalOpen}
        onClose={() => setDeleteModalOpen(false)}
        onConfirm={handleDeleteConfirm}
        title="Eliminar Ejercicio"
        message={`¿Estás seguro de que deseas eliminar este ejercicio de la rutina? Esta acción no se puede deshacer.`}
        confirmLabel="Eliminar"
        isDanger
        isLoading={isDeleting}
      />
    </div>
  );
};