import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Card, 
  CardBody, 
  Input, 
  Button, 
  Select,
  SelectItem,
  Spinner
} from '@heroui/react';
import { Icon } from '@iconify/react';
import { useForm, Controller } from 'react-hook-form';
import { PageHeader } from '../../components/ui/page-header';
import { routineApi, clientApi } from '../../services/api';
import { RoutineFormData, Client } from '../../types';
import { addToast } from '@heroui/react';

export const RoutineCreate: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const clientIdParam = queryParams.get('clienteId');
  
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [clients, setClients] = React.useState<Client[]>([]);
  const [loadingClients, setLoadingClients] = React.useState(true);
  
  const { 
    control, 
    handleSubmit, 
    formState: { errors },
    setValue
  } = useForm<RoutineFormData>({
    defaultValues: {
      nombre: '',
      enfoque: 'Tonificar',
      fechaInicio: new Date().toISOString().split('T')[0],
      fechaFin: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      clienteId: clientIdParam ? parseInt(clientIdParam) : undefined
    }
  });
  
  React.useEffect(() => {
    fetchClients();
  }, []);
  
  React.useEffect(() => {
    if (clientIdParam) {
      setValue('clienteId', parseInt(clientIdParam));
    }
  }, [clientIdParam, setValue]);
  
  const fetchClients = async () => {
    try {
      setLoadingClients(true);
      const data = await clientApi.getAll();
      setClients(data);
    } catch (error) {
      console.error('Error fetching clients:', error);
      addToast({
        title: 'Error',
        description: 'No se pudieron cargar los clientes',
        severity: 'danger'
      });
    } finally {
      setLoadingClients(false);
    }
  };
  
  const onSubmit = async (data: RoutineFormData) => {
    try {
      setIsSubmitting(true);
      await routineApi.create({
        nombre: data.nombre,
        enfoque: data.enfoque,
        fechaInicio: data.fechaInicio,
        fechaFin: data.fechaFin,
        clienteId: data.clienteId
      });
      
      addToast({
        title: 'Rutina creada',
        description: 'La rutina ha sido creada correctamente',
        severity: 'success'
      });
      navigate('/rutinas');
    } catch (error) {
      console.error('Error creating routine:', error);
      addToast({
        title: 'Error',
        description: 'No se pudo crear la rutina',
        severity: 'danger'
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div>
      <PageHeader 
        title="Crear Rutina" 
        description="Añade una nueva rutina de entrenamiento" 
        backLink="/rutinas"
      />
      
      <Card className="max-w-xl mx-auto">
        <CardBody className="p-6">
          {loadingClients ? (
            <div className="flex justify-center items-center h-40">
              <Spinner size="lg" color="primary" />
            </div>
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <Controller
                name="nombre"
                control={control}
                rules={{ 
                  required: 'El nombre es obligatorio',
                  minLength: {
                    value: 3,
                    message: 'El nombre debe tener al menos 3 caracteres'
                  }
                }}
                render={({ field }) => (
                  <Input
                    {...field}
                    label="Nombre"
                    placeholder="Ingrese el nombre de la rutina"
                    isRequired
                    isInvalid={!!errors.nombre}
                    errorMessage={errors.nombre?.message}
                  />
                )}
              />
              
              <Controller
                name="enfoque"
                control={control}
                rules={{ required: 'El enfoque es obligatorio' }}
                render={({ field }) => (
                  <Select
                    label="Enfoque"
                    placeholder="Seleccione un enfoque"
                    selectedKeys={[field.value]}
                    onChange={(e) => field.onChange(e.target.value)}
                    isRequired
                    isInvalid={!!errors.enfoque}
                    errorMessage={errors.enfoque?.message}
                  >
                    <SelectItem key="Tonificar" value="Tonificar">Tonificar</SelectItem>
                    <SelectItem key="Volumen" value="Volumen">Volumen</SelectItem>
                    <SelectItem key="Resistencia" value="Resistencia">Resistencia</SelectItem>
                  </Select>
                )}
              />
              
              <Controller
                name="fechaInicio"
                control={control}
                rules={{ required: 'La fecha de inicio es obligatoria' }}
                render={({ field }) => (
                  <Input
                    {...field}
                    type="date"
                    label="Fecha de Inicio"
                    isRequired
                    isInvalid={!!errors.fechaInicio}
                    errorMessage={errors.fechaInicio?.message}
                  />
                )}
              />
              
              <Controller
                name="fechaFin"
                control={control}
                rules={{ 
                  required: 'La fecha de fin es obligatoria',
                  validate: (value, formValues) => {
                    if (new Date(value) <= new Date(formValues.fechaInicio)) {
                      return 'La fecha de fin debe ser posterior a la fecha de inicio';
                    }
                    return true;
                  }
                }}
                render={({ field }) => (
                  <Input
                    {...field}
                    type="date"
                    label="Fecha de Fin"
                    isRequired
                    isInvalid={!!errors.fechaFin}
                    errorMessage={errors.fechaFin?.message}
                  />
                )}
              />
              
              <Controller
                name="clienteId"
                control={control}
                rules={{ required: 'El cliente es obligatorio' }}
                render={({ field }) => (
                  <Select
                    label="Cliente"
                    placeholder="Seleccione un cliente"
                    selectedKeys={field.value ? [field.value.toString()] : []}
                    onChange={(e) => field.onChange(parseInt(e.target.value))}
                    isRequired
                    isInvalid={!!errors.clienteId}
                    errorMessage={errors.clienteId?.message}
                  >
                    {clients.map((client) => (
                      <SelectItem key={client.id?.toString()} value={client.id?.toString() || ''}>
                        {client.nombre}
                      </SelectItem>
                    ))}
                  </Select>
                )}
              />
              
              <div className="flex justify-end gap-3 pt-4">
                <Button
                  variant="flat"
                  onPress={() => navigate('/rutinas')}
                  isDisabled={isSubmitting}
                >
                  Cancelar
                </Button>
                <Button
                  color="primary"
                  type="submit"
                  isLoading={isSubmitting}
                  startContent={!isSubmitting && <Icon icon="lucide:save" className="h-4 w-4" />}
                >
                  Guardar
                </Button>
              </div>
            </form>
          )}
        </CardBody>
      </Card>
    </div>
  );
};