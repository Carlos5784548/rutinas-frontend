import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Card, 
  CardBody, 
  Input, 
  Button, 
  Select, 
  SelectItem 
} from '@heroui/react';
import { Icon } from '@iconify/react';
import { useForm, Controller } from 'react-hook-form';
import { PageHeader } from '../../components/ui/page-header';
import { userApi } from '../../services/api';
import { UserFormData } from '../../types';
import { addToast } from '@heroui/react';

export const UserCreate: React.FC = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  
  const { 
    control, 
    handleSubmit, 
    formState: { errors } 
  } = useForm<UserFormData>({
    defaultValues: {
      nombre: '',
      email: '',
      password: '',
      rol: 'CLIENTE'
    }
  });
  
  const onSubmit = async (data: UserFormData) => {
    try {
      setIsSubmitting(true);
      await userApi.create(data);
      addToast({
        title: 'Usuario creado',
        description: 'El usuario ha sido creado correctamente',
        severity: 'success'
      });
      navigate('/usuarios');
    } catch (error) {
      console.error('Error creating user:', error);
      addToast({
        title: 'Error',
        description: 'No se pudo crear el usuario',
        severity: 'danger'
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div>
      <PageHeader 
        title="Crear Usuario" 
        description="Añade un nuevo usuario al sistema" 
        backLink="/usuarios"
      />
      
      <Card className="max-w-xl mx-auto">
        <CardBody className="p-6">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <Controller
              name="nombre"
              control={control}
              rules={{ 
                required: 'El nombre es obligatorio',
                minLength: {
                  value: 3,
                  message: 'El nombre debe tener al menos 3 caracteres'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  label="Nombre"
                  placeholder="Ingrese el nombre completo"
                  isRequired
                  isInvalid={!!errors.nombre}
                  errorMessage={errors.nombre?.message}
                />
              )}
            />
            
            <Controller
              name="email"
              control={control}
              rules={{ 
                required: 'El email es obligatorio',
                pattern: {
                  value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                  message: 'Ingrese un email válido'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  type="email"
                  label="Email"
                  placeholder="ejemplo@correo.com"
                  isRequired
                  isInvalid={!!errors.email}
                  errorMessage={errors.email?.message}
                />
              )}
            />
            
            <Controller
              name="password"
              control={control}
              rules={{ 
                required: 'La contraseña es obligatoria',
                minLength: {
                  value: 6,
                  message: 'La contraseña debe tener al menos 6 caracteres'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  type="password"
                  label="Contraseña"
                  placeholder="Ingrese una contraseña"
                  isRequired
                  isInvalid={!!errors.password}
                  errorMessage={errors.password?.message}
                />
              )}
            />
            
            <Controller
              name="rol"
              control={control}
              rules={{ required: 'El rol es obligatorio' }}
              render={({ field }) => (
                <Select
                  label="Rol"
                  placeholder="Seleccione un rol"
                  selectedKeys={[field.value]}
                  onChange={(e) => field.onChange(e.target.value)}
                  isRequired
                  isInvalid={!!errors.rol}
                  errorMessage={errors.rol?.message}
                >
                  <SelectItem key="ADMIN" value="ADMIN">Administrador</SelectItem>
                  <SelectItem key="CLIENTE" value="CLIENTE">Cliente</SelectItem>
                  <SelectItem key="ENTRENADOR" value="ENTRENADOR">Entrenador</SelectItem>
                </Select>
              )}
            />
            
            <div className="flex justify-end gap-3 pt-4">
              <Button
                variant="flat"
                onPress={() => navigate('/usuarios')}
                isDisabled={isSubmitting}
              >
                Cancelar
              </Button>
              <Button
                color="primary"
                type="submit"
                isLoading={isSubmitting}
                startContent={!isSubmitting && <Icon icon="lucide:save" className="h-4 w-4" />}
              >
                Guardar
              </Button>
            </div>
          </form>
        </CardBody>
      </Card>
    </div>
  );
};