import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Card, 
  CardBody, 
  Input, 
  Button, 
  Textarea
} from '@heroui/react';
import { Icon } from '@iconify/react';
import { useForm, Controller } from 'react-hook-form';
import { PageHeader } from '../../components/ui/page-header';
import { exerciseApi } from '../../services/api';
import { ExerciseFormData } from '../../types';
import { addToast } from '@heroui/react';

export const ExerciseCreate: React.FC = () => {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  
  const { 
    control, 
    handleSubmit, 
    formState: { errors } 
  } = useForm<ExerciseFormData>({
    defaultValues: {
      nombre: '',
      grupoMuscular: '',
      descripcion: ''
    }
  });
  
  const onSubmit = async (data: ExerciseFormData) => {
    try {
      setIsSubmitting(true);
      await exerciseApi.create(data);
      addToast({
        title: 'Ejercicio creado',
        description: 'El ejercicio ha sido creado correctamente',
        severity: 'success'
      });
      navigate('/ejercicios');
    } catch (error) {
      console.error('Error creating exercise:', error);
      addToast({
        title: 'Error',
        description: 'No se pudo crear el ejercicio',
        severity: 'danger'
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div>
      <PageHeader 
        title="Crear Ejercicio" 
        description="Añade un nuevo ejercicio al sistema" 
        backLink="/ejercicios"
      />
      
      <Card className="max-w-xl mx-auto">
        <CardBody className="p-6">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <Controller
              name="nombre"
              control={control}
              rules={{ 
                required: 'El nombre es obligatorio',
                minLength: {
                  value: 3,
                  message: 'El nombre debe tener al menos 3 caracteres'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  label="Nombre"
                  placeholder="Ingrese el nombre del ejercicio"
                  isRequired
                  isInvalid={!!errors.nombre}
                  errorMessage={errors.nombre?.message}
                />
              )}
            />
            
            <Controller
              name="grupoMuscular"
              control={control}
              rules={{ 
                required: 'El grupo muscular es obligatorio',
                minLength: {
                  value: 3,
                  message: 'El grupo muscular debe tener al menos 3 caracteres'
                }
              }}
              render={({ field }) => (
                <Input
                  {...field}
                  label="Grupo Muscular"
                  placeholder="Ej: Pecho, Espalda, Piernas, etc."
                  isRequired
                  isInvalid={!!errors.grupoMuscular}
                  errorMessage={errors.grupoMuscular?.message}
                />
              )}
            />
            
            <Controller
              name="descripcion"
              control={control}
              rules={{ 
                required: 'La descripción es obligatoria',
                minLength: {
                  value: 10,
                  message: 'La descripción debe tener al menos 10 caracteres'
                }
              }}
              render={({ field }) => (
                <Textarea
                  {...field}
                  label="Descripción"
                  placeholder="Ingrese una descripción detallada del ejercicio"
                  isRequired
                  isInvalid={!!errors.descripcion}
                  errorMessage={errors.descripcion?.message}
                  minRows={4}
                />
              )}
            />
            
            <div className="flex justify-end gap-3 pt-4">
              <Button
                variant="flat"
                onPress={() => navigate('/ejercicios')}
                isDisabled={isSubmitting}
              >
                Cancelar
              </Button>
              <Button
                color="primary"
                type="submit"
                isLoading={isSubmitting}
                startContent={!isSubmitting && <Icon icon="lucide:save" className="h-4 w-4" />}
              >
                Guardar
              </Button>
            </div>
          </form>
        </CardBody>
      </Card>
    </div>
  );
};