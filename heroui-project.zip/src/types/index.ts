// User entity
export interface User {
  id?: number;
  nombre: string;
  email: string;
  password?: string;
  rol: 'ADMIN' | 'CLIENTE' | 'ENTRENADOR';
}

// Client entity
export interface Client {
  id?: number;
  nombre: string;
  email: string;
  telefono: string;
  edad: number;
  usuario?: User;
  usuarioId?: number;
  rutinas?: Routine[];
}

// Routine entity
export interface Routine {
  id?: number;
  nombre: string;
  enfoque: 'Tonificar' | 'Volumen' | 'Resistencia';
  fechaInicio: string;
  fechaFin: string;
  clienteId: number;
  cliente?: Client;
  ejercicios?: RoutineExercise[];
}

// Exercise entity
export interface Exercise {
  id?: number;
  nombre: string;
  grupoMuscular: string;
  descripcion: string;
}

// RoutineExercise entity
export interface RoutineExercise {
  id?: number;
  series: number;
  repeticiones: number;
  descansoSegundos: number;
  rutinaId?: number;
  ejercicioId: number;
  ejercicio?: Exercise;
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  message?: string;
  status: number;
}

export interface PaginatedResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
}

// Form types
export interface UserFormData {
  nombre: string;
  email: string;
  password: string;
  rol: 'ADMIN' | 'CLIENTE' | 'ENTRENADOR';
}

export interface ClientFormData {
  nombre: string;
  email: string;
  telefono: string;
  edad: number;
  usuario: {
    nombre: string;
    email: string;
    password: string;
    rol: 'CLIENTE';
  };
}

export interface RoutineFormData {
  nombre: string;
  enfoque: 'Tonificar' | 'Volumen' | 'Resistencia';
  fechaInicio: string;
  fechaFin: string;
  clienteId: number;
}

export interface ExerciseFormData {
  nombre: string;
  grupoMuscular: string;
  descripcion: string;
}

export interface RoutineExerciseFormData {
  ejercicioId: number;
  series: number;
  repeticiones: number;
  descansoSegundos: number;
}

// Filter types
export interface UserFilter {
  rol?: 'ADMIN' | 'CLIENTE' | 'ENTRENADOR';
  search?: string;
}

export interface ExerciseFilter {
  grupoMuscular?: string;
  search?: string;
}

export interface RoutineFilter {
  enfoque?: 'Tonificar' | 'Volumen' | 'Resistencia';
  clienteId?: number;
  search?: string;
}
