import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Button, Divider } from '@heroui/react';
import { Icon } from '@iconify/react';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
}

interface NavItem {
  label: string;
  path: string;
  icon: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onToggle }) => {
  const location = useLocation();
  
  const navItems: NavItem[] = [
    { label: 'Dashboard', path: '/', icon: 'lucide:layout-dashboard' },
    { label: 'Usuarios', path: '/usuarios', icon: 'lucide:users' },
    { label: 'Clientes', path: '/clientes', icon: 'lucide:user' },
    { label: 'Rutinas', path: '/rutinas', icon: 'lucide:clipboard-list' },
    { label: 'Ejercicios', path: '/ejercicios', icon: 'lucide:dumbbell' },
  ];
  
  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === path;
    }
    return location.pathname.startsWith(path);
  };
  
  return (
    <aside 
      className={`${
        isOpen ? 'w-64' : 'w-20'
      } bg-content1 shadow-sm transition-all duration-300 ease-in-out fixed md:relative z-30 h-screen`}
    >
      <div className="flex flex-col h-full">
        <div className={`flex items-center justify-between h-16 px-4 ${isOpen ? 'justify-between' : 'justify-center'}`}>
          {isOpen ? (
            <div className="flex items-center">
              <Icon icon="lucide:dumbbell" className="h-8 w-8 text-primary" />
              <span className="ml-2 text-lg font-semibold text-foreground">FitManager</span>
            </div>
          ) : (
            <Icon icon="lucide:dumbbell" className="h-8 w-8 text-primary" />
          )}
          
          <Button 
            isIconOnly
            variant="light"
            aria-label="Toggle sidebar"
            className="md:flex hidden"
            onPress={onToggle}
          >
            <Icon 
              icon={isOpen ? 'lucide:chevron-left' : 'lucide:chevron-right'} 
              className="h-5 w-5"
            />
          </Button>
        </div>
        
        <Divider />
        
        <nav className="flex-1 overflow-y-auto py-4">
          <ul className="space-y-1 px-3">
            {navItems.map((item) => (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={({ isActive }) => 
                    `flex items-center px-3 py-2 rounded-md transition-colors ${
                      isActive 
                        ? 'bg-primary-100 text-primary-600' 
                        : 'text-foreground-600 hover:bg-default-100'
                    }`
                  }
                >
                  <Icon icon={item.icon} className="h-5 w-5 flex-shrink-0" />
                  {isOpen && <span className="ml-3 text-sm">{item.label}</span>}
                </NavLink>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="p-4">
          <Button
            variant="flat"
            color="danger"
            className={`w-full justify-start ${!isOpen && 'justify-center'}`}
            startContent={isOpen ? <Icon icon="lucide:log-out" className="h-5 w-5" /> : undefined}
          >
            {isOpen ? 'Cerrar Sesión' : <Icon icon="lucide:log-out" className="h-5 w-5" />}
          </Button>
        </div>
      </div>
    </aside>
  );
};