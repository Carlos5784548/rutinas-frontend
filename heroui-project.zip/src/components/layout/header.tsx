import React from 'react';
import { Button, Dropdown, DropdownTrigger, DropdownMenu, DropdownItem, Avatar } from '@heroui/react';
import { Icon } from '@iconify/react';

interface HeaderProps {
  onMenuClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  return (
    <header className="bg-content1 shadow-sm h-16 flex items-center px-4 md:px-6">
      <Button 
        isIconOnly
        variant="light"
        aria-label="Menu"
        className="md:hidden"
        onPress={onMenuClick}
      >
        <Icon icon="lucide:menu" className="h-5 w-5" />
      </Button>
      
      <div className="flex-1 flex justify-end items-center space-x-4">
        <Button
          variant="light"
          isIconOnly
          aria-label="Notifications"
        >
          <Icon icon="lucide:bell" className="h-5 w-5" />
        </Button>
        
        <Dropdown placement="bottom-end">
          <DropdownTrigger>
            <Button
              variant="light"
              className="flex items-center gap-2"
            >
              <Avatar
                name="Admin"
                size="sm"
                className="transition-transform"
              />
              <span className="hidden md:block text-sm font-medium">Admin</span>
              <Icon icon="lucide:chevron-down" className="h-4 w-4" />
            </Button>
          </DropdownTrigger>
          <DropdownMenu aria-label="User Actions">
            <DropdownItem key="profile" startContent={<Icon icon="lucide:user" className="h-4 w-4" />}>
              Mi Perfil
            </DropdownItem>
            <DropdownItem key="settings" startContent={<Icon icon="lucide:settings" className="h-4 w-4" />}>
              Configuración
            </DropdownItem>
            <DropdownItem key="logout" startContent={<Icon icon="lucide:log-out" className="h-4 w-4" />} className="text-danger" color="danger">
              Cerrar Sesión
            </DropdownItem>
          </DropdownMenu>
        </Dropdown>
      </div>
    </header>
  );
};