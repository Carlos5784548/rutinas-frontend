import React from 'react';
import { Alert, Button } from '@heroui/react';
import { Icon } from '@iconify/react';

interface ApiError {
  title: string;
  message: string;
  details?: string;
  status?: number;
}

interface ErrorAlertProps {
  error: ApiError | null;
  onRetry?: () => void;
  onDismiss?: () => void;
}

export const ErrorAlert: React.FC<ErrorAlertProps> = ({ 
  error, 
  onRetry, 
  onDismiss 
}) => {
  if (!error) return null;
  
  return (
    <Alert 
      className="mb-4"
      color="danger"
      variant="flat"
      isClosable={!!onDismiss}
      onClose={onDismiss}
    >
      <div className="flex gap-2">
        <Icon icon="lucide:alert-circle" className="h-5 w-5 text-danger" />
        <div className="flex-1">
          <h5 className="font-medium">{error.title}</h5>
          <p className="text-sm">{error.message}</p>
          {error.details && (
            <p className="text-xs mt-1 text-danger-600">{error.details}</p>
          )}
          {onRetry && (
            <Button 
              size="sm" 
              color="danger" 
              variant="flat" 
              className="mt-2"
              onPress={onRetry}
              startContent={<Icon icon="lucide:refresh-cw" className="h-4 w-4" />}
            >
              Reintentar
            </Button>
          )}
        </div>
      </div>
    </Alert>
  );
};