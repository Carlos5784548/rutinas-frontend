import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { MainLayout } from './components/layout/main-layout';
import { Dashboard } from './pages/dashboard';
import { UserList } from './pages/users/user-list';
import { UserCreate } from './pages/users/user-create';
import { ClientList } from './pages/clients/client-list';
import { ClientCreate } from './pages/clients/client-create';
import { ClientDetail } from './pages/clients/client-detail';
import { RoutineList } from './pages/routines/routine-list';
import { RoutineCreate } from './pages/routines/routine-create';
import { RoutineDetail } from './pages/routines/routine-detail';
import { ExerciseList } from './pages/exercises/exercise-list';
import { ExerciseCreate } from './pages/exercises/exercise-create';
import { ExerciseEdit } from './pages/exercises/exercise-edit';

function App() {
  return (
    <Routes>
      <Route path="/" element={<MainLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="usuarios">
          <Route index element={<UserList />} />
          <Route path="crear" element={<UserCreate />} />
        </Route>
        <Route path="clientes">
          <Route index element={<ClientList />} />
          <Route path="crear" element={<ClientCreate />} />
          <Route path=":id" element={<ClientDetail />} />
        </Route>
        <Route path="rutinas">
          <Route index element={<RoutineList />} />
          <Route path="crear" element={<RoutineCreate />} />
          <Route path=":id" element={<RoutineDetail />} />
        </Route>
        <Route path="ejercicios">
          <Route index element={<ExerciseList />} />
          <Route path="crear" element={<ExerciseCreate />} />
          <Route path=":id/editar" element={<ExerciseEdit />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

export default App;