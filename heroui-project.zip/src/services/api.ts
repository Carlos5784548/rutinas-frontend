import axios, { AxiosError, AxiosResponse } from 'axios';
import { 
  User, 
  Client, 
  Routine, 
  Exercise, 
  RoutineExercise,
  UserFilter,
  ExerciseFilter,
  RoutineFilter,
  PaginatedResponse
} from '../types';
import { addToast } from '@heroui/react';

const API_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 seconds timeout
});

// Error handling interceptor - Improved version
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError) => {
    let errorMessage = 'Ha ocurrido un error desconocido';
    let errorTitle = 'Error';
    let errorDetails = '';
    
    if (error.response) {
      // The request was made and the server responded with a status code
      // that falls out of the range of 2xx
      const status = error.response.status;
      const data = error.response.data as any;
      
      switch (status) {
        case 400:
          errorTitle = 'Error de validación';
          errorMessage = data.message || 'Los datos enviados no son válidos';
          if (data.errors && Array.isArray(data.errors)) {
            errorDetails = data.errors.map((err: any) => err.defaultMessage || err.message).join(', ');
          }
          break;
        case 401:
          errorTitle = 'No autorizado';
          errorMessage = 'No tiene permisos para realizar esta acción';
          break;
        case 403:
          errorTitle = 'Acceso denegado';
          errorMessage = 'No tiene permisos suficientes para acceder a este recurso';
          break;
        case 404:
          errorTitle = 'No encontrado';
          errorMessage = 'El recurso solicitado no existe';
          break;
        case 409:
          errorTitle = 'Conflicto';
          errorMessage = data.message || 'Ya existe un recurso con estos datos';
          break;
        case 500:
          errorTitle = 'Error del servidor';
          errorMessage = 'Ha ocurrido un error en el servidor';
          break;
        default:
          errorTitle = `Error ${status}`;
          errorMessage = data.message || 'Ha ocurrido un error en la solicitud';
      }
    } else if (error.request) {
      // The request was made but no response was received
      errorTitle = 'Error de conexión';
      errorMessage = 'No se pudo conectar con el servidor. Verifique su conexión a internet.';
    } else {
      // Something happened in setting up the request that triggered an Error
      errorTitle = 'Error de solicitud';
      errorMessage = error.message || 'Error al procesar la solicitud';
    }
    
    // Log the detailed error for debugging
    console.error('API Error:', {
      title: errorTitle,
      message: errorMessage,
      details: errorDetails,
      originalError: error
    });
    
    // Show toast notification for network errors
    if (error.code === 'ECONNABORTED' || !error.response) {
      addToast({
        title: errorTitle,
        description: errorMessage,
        severity: 'danger'
      });
    }
    
    // Return a rejected promise with structured error information
    return Promise.reject({
      title: errorTitle,
      message: errorMessage,
      details: errorDetails,
      originalError: error,
      status: error.response?.status
    });
  }
);

// Users API
export const userApi = {
  getAll: async (filter?: UserFilter): Promise<User[]> => {
    const params = filter ? { ...filter } : {};
    const response: AxiosResponse<User[]> = await api.get('/usuarios', { params });
    return response.data;
  },
  
  getById: async (id: number): Promise<User> => {
    const response: AxiosResponse<User> = await api.get(`/usuarios/${id}`);
    return response.data;
  },
  
  create: async (user: User): Promise<User> => {
    const response: AxiosResponse<User> = await api.post('/usuarios', user);
    return response.data;
  },
  
  update: async (id: number, user: User): Promise<User> => {
    const response: AxiosResponse<User> = await api.put(`/usuarios/${id}`, user);
    return response.data;
  },
  
  delete: async (id: number): Promise<void> => {
    await api.delete(`/usuarios/${id}`);
  }
};

// Clients API
export const clientApi = {
  getAll: async (): Promise<Client[]> => {
    const response: AxiosResponse<Client[]> = await api.get('/clientes');
    return response.data;
  },
  
  getById: async (id: number): Promise<Client> => {
    const response: AxiosResponse<Client> = await api.get(`/clientes/${id}`);
    return response.data;
  },
  
  create: async (client: Client): Promise<Client> => {
    const response: AxiosResponse<Client> = await api.post('/clientes', client);
    return response.data;
  },
  
  update: async (id: number, client: Client): Promise<Client> => {
    const response: AxiosResponse<Client> = await api.put(`/clientes/${id}`, client);
    return response.data;
  },
  
  delete: async (id: number): Promise<void> => {
    await api.delete(`/clientes/${id}`);
  },
  
  getRoutines: async (id: number): Promise<Routine[]> => {
    const response: AxiosResponse<Routine[]> = await api.get(`/clientes/${id}/rutinas`);
    return response.data;
  }
};

// Routines API
export const routineApi = {
  getAll: async (filter?: RoutineFilter): Promise<Routine[]> => {
    const params = filter ? { ...filter } : {};
    const response: AxiosResponse<Routine[]> = await api.get('/rutinas', { params });
    return response.data;
  },
  
  getById: async (id: number): Promise<Routine> => {
    const response: AxiosResponse<Routine> = await api.get(`/rutinas/${id}`);
    return response.data;
  },
  
  create: async (routine: Routine): Promise<Routine> => {
    const response: AxiosResponse<Routine> = await api.post('/rutinas', routine);
    return response.data;
  },
  
  update: async (id: number, routine: Routine): Promise<Routine> => {
    const response: AxiosResponse<Routine> = await api.put(`/rutinas/${id}`, routine);
    return response.data;
  },
  
  delete: async (id: number): Promise<void> => {
    await api.delete(`/rutinas/${id}`);
  },
  
  addExercise: async (routineId: number, routineExercise: RoutineExercise): Promise<RoutineExercise> => {
    const response: AxiosResponse<RoutineExercise> = await api.post(`/rutinas/${routineId}/ejercicios`, routineExercise);
    return response.data;
  },
  
  getExercises: async (routineId: number): Promise<RoutineExercise[]> => {
    const response: AxiosResponse<RoutineExercise[]> = await api.get(`/rutinas/${routineId}/ejercicios`);
    return response.data;
  },
  
  removeExercise: async (routineId: number, exerciseId: number): Promise<void> => {
    await api.delete(`/rutinas/${routineId}/ejercicios/${exerciseId}`);
  }
};

// Exercises API
export const exerciseApi = {
  getAll: async (filter?: ExerciseFilter): Promise<Exercise[]> => {
    const params = filter ? { ...filter } : {};
    const response: AxiosResponse<Exercise[]> = await api.get('/ejercicios', { params });
    return response.data;
  },
  
  getById: async (id: number): Promise<Exercise> => {
    const response: AxiosResponse<Exercise> = await api.get(`/ejercicios/${id}`);
    return response.data;
  },
  
  create: async (exercise: Exercise): Promise<Exercise> => {
    const response: AxiosResponse<Exercise> = await api.post('/ejercicios', exercise);
    return response.data;
  },
  
  update: async (id: number, exercise: Exercise): Promise<Exercise> => {
    const response: AxiosResponse<Exercise> = await api.put(`/ejercicios/${id}`, exercise);
    return response.data;
  },
  
  delete: async (id: number): Promise<void> => {
    await api.delete(`/ejercicios/${id}`);
  },
  
  getMuscleGroups: async (): Promise<string[]> => {
    const response: AxiosResponse<string[]> = await api.get('/ejercicios/grupos-musculares');
    return response.data;
  }
};

export default api;
